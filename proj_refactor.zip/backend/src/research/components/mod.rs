//! Research domain components

pub mod feed;
