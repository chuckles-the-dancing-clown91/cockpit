//! Writing domain components

pub mod ideas;
pub mod article_viewer;
pub mod knowledge_graph;
