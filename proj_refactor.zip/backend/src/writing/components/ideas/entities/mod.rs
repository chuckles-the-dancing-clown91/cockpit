//! Database entities for ideas

pub mod idea_references;
