SELECT COUNT(*) as total_tasks FROM system_tasks;
SELECT * FROM system_tasks;
SELECT COUNT(*) as total_runs FROM system_task_runs;
