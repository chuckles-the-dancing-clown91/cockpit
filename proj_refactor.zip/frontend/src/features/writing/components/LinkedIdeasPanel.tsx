import { useState } from 'react';
import { Flex, Text, Button } from '@radix-ui/themes';
import { FolderTree, Plus } from 'lucide-react';
import { useLinkedIdeas, useUnlinkIdea } from '../hooks/useWriting';
import { useIdeas, useUpdateIdea } from '@/features/ideas/hooks/useIdeas';
import { IdeaCard, IdeaDetailDialog } from '@/features/ideas';
import { LoadingInline, EmptyState } from '@/core/components/ui';
import { LinkIdeaDialog } from './LinkIdeaDialog';
import { useDialog } from '@/core/providers/DialogProvider';
import { toast } from '@/core/lib/toast';
import type { Idea, IdeaStatus } from '@/shared/types';

interface LinkedIdeasPanelProps {
  writingId: number;
}

/**
 * LinkedIdeasPanel - Shows ideas linked to a writing
 * 
 * Leverages existing IdeaCard component from ideas feature:
 * - Displays linked ideas using IdeaCard
 * - Click to open IdeaDetailDialog
 * - Unlink ideas with confirmation
 * - Link new ideas button
 */
export function LinkedIdeasPanel({ writingId }: LinkedIdeasPanelProps) {
  const [showLinkDialog, setShowLinkDialog] = useState(false);
  const [selectedIdea, setSelectedIdea] = useState<Idea | null>(null);
  const { data: ideaIds, isLoading: idsLoading, error } = useLinkedIdeas(writingId);
  const { data: allIdeas, isLoading: ideasLoading } = useIdeas();
  const unlinkIdea = useUnlinkIdea(writingId);
  const updateIdea = useUpdateIdea();
  const dialog = useDialog();
  
  if (idsLoading || ideasLoading) {
    return (
      <Flex direction="column" gap="2" p="4">
        <LoadingInline message="Loading linked ideas..." />
      </Flex>
    );
  }
  
  // Show error but still allow linking new ideas
  if (error) {
    return (
      <>
        <Flex direction="column" gap="4" p="4">
          <Text size="2" color="red">
            Failed to load linked ideas
          </Text>
          {error instanceof Error && (
            <Text size="1" style={{ color: 'var(--color-text-muted)' }}>
              {error.message}
            </Text>
          )}
          <Button size="2" onClick={() => setShowLinkDialog(true)}>
            <Plus size={16} />
            Link Idea
          </Button>
        </Flex>
        <LinkIdeaDialog 
          writingId={writingId} 
          open={showLinkDialog} 
          onClose={() => setShowLinkDialog(false)} 
        />
      </>
    );
  }
  
  // Filter allIdeas to only include linked ones
  const linkedIdeas = (allIdeas || []).filter(idea => 
    ideaIds && Array.isArray(ideaIds) && ideaIds.includes(idea.id)
  );
  
  // Debug logging
  console.log('LinkedIdeasPanel debug:', {
    writingId,
    ideaIds,
    ideaIdsLength: ideaIds?.length,
    allIdeasLength: allIdeas?.length,
    linkedIdeasLength: linkedIdeas.length,
    firstIdeaId: ideaIds?.[0],
    firstAllIdeaId: allIdeas?.[0]?.id,
  });
  
  const handleUnlink = async (ideaId: number) => {
    const confirmed = await dialog.confirm({
      title: 'Unlink Idea',
      description: 'Remove this idea from the writing? The idea itself will not be deleted.',
    });
    
    if (confirmed) {
      try {
        await unlinkIdea.mutateAsync(ideaId);
        toast.success('Idea unlinked');
      } catch (error) {
        toast.error('Failed to unlink idea');
      }
    }
  };
  
  const handleStatusChange = async (id: number, status: IdeaStatus) => {
    await updateIdea.mutateAsync({ id, status });
  };
  
  if (linkedIdeas.length === 0) {
    return (
      <>
        <EmptyState
          icon={FolderTree}
          title="No linked ideas"
          description="Link ideas to organize your research and writing"
          action={{
            label: 'Link Idea',
            onClick: () => setShowLinkDialog(true),
            icon: Plus,
          }}
        />
        <LinkIdeaDialog 
          writingId={writingId} 
          open={showLinkDialog} 
          onClose={() => setShowLinkDialog(false)} 
        />
      </>
    );
  }
  
  return (
    <>
      <Flex direction="column" gap="3" p="4" style={{ height: '100%', overflow: 'auto' }}>
        <Flex justify="between" align="center">
          <Text size="2" weight="bold" style={{ color: 'var(--color-text-primary)' }}>
            Linked Ideas ({linkedIdeas.length})
          </Text>
          <Button size="1" variant="soft" onClick={() => setShowLinkDialog(true)}>
            <Plus size={14} />
          </Button>
        </Flex>
        
        <Flex direction="column" gap="2">
          {linkedIdeas.map((idea) => (
            <IdeaCard
              key={idea.id}
              idea={idea}
              onClick={() => setSelectedIdea(idea)}
              onStatusChange={handleStatusChange}
              onArchive={() => handleUnlink(idea.id)}
            //   archiveLabel="Unlink"
            />
          ))}
        </Flex>
      </Flex>
      
      {/* Idea Detail Dialog */}
      <IdeaDetailDialog
        idea={selectedIdea}
        open={!!selectedIdea}
        onClose={() => setSelectedIdea(null)}
        onOpenWriting={(writingId) => {
          toast.success(`Article created! Writing ID: ${writingId}`);
          console.log('Navigate to writing:', writingId);
        }}
      />
      
      {/* Link Idea Dialog */}
      <LinkIdeaDialog 
        writingId={writingId} 
        open={showLinkDialog} 
        onClose={() => setShowLinkDialog(false)} 
      />
    </>
  );
}
